package com.example.kotlinandroid_aboutme


import kotlinx.android.synthetic.main.activity_visual_spot_checking.*
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    // to optimize the app, it will not search through R.id on run time


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.done_button).setOnClickListener {
            addNickName(it)
            toggleTextView()
        }
        findViewById<TextView>(R.id.tv_nick_name).setOnClickListener {
            toggleTextView()
        }
    }
    private fun toggleTextView(){

            // toggle edit text view and button
        nick_name.visibility = if (nameText.visibility.compareTo(View.GONE)==0) View.VISIBLE else View.GONE
            doneButton.visibility = if (doneButton.visibility.compareTo(View.GONE)==0) View.VISIBLE else View.GONE
            // toggle the nick name text view field
            tvNickName.visibility = if (tvNickName.visibility.compareTo(View.GONE)==0) View.VISIBLE else View.GONE


    }
    private fun addNickName(view: View){

        binding.tvNickName.text = binding.nickName.text

        // close keyboard
        val inm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inm.hideSoftInputFromWindow(view.windowToken,0)
    }
}